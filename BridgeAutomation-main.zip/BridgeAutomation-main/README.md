
# BridgeAutomation

Софт для автоматизации транзакций черз мосты


## Documentation

```bash
git clone https://github.com/BridgeAutomation.git

cd BridgeAutomation

pip install -r requirements.txt

python main.py
```

Настройки производятся в папке user_settings, внутри присутствует коментарии, что и где писать

## Authors

- [@0xNsi4b](https://github.com/0xNsi4b)
- [@Messxrem](https://github.com/Messxrem)



![Logo](https://i.ibb.co/NnC2RhQ/2023-11-02-21-01-10.png)

